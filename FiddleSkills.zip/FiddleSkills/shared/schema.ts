import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"), 
  profileImageUrl: varchar("profile_image_url"),
  // Violin learning specific fields
  username: text("username").unique(),
  totalXp: integer("total_xp").notNull().default(0),
  currentStreak: integer("current_streak").notNull().default(0),
  longestStreak: integer("longest_streak").notNull().default(0),
  lessonsCompleted: integer("lessons_completed").notNull().default(0),
  practiceTimeMinutes: integer("practice_time_minutes").notNull().default(0),
  currentLevel: integer("current_level").notNull().default(1),
  dailyGoalMinutes: integer("daily_goal_minutes").notNull().default(20),
  todayPracticeMinutes: integer("today_practice_minutes").notNull().default(0),
  lastPracticeDate: text("last_practice_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const units = pgTable("units", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  orderIndex: integer("order_index").notNull(),
  color: text("color").notNull().default("blue"),
  isLocked: boolean("is_locked").notNull().default(true),
});

export const lessons = pgTable("lessons", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  unitId: varchar("unit_id").references(() => units.id).notNull(),
  name: text("name").notNull(),
  description: text("description"),
  orderIndex: integer("order_index").notNull(),
  xpReward: integer("xp_reward").notNull().default(50),
  content: jsonb("content").notNull(), // Lesson content structure
  audioUrl: text("audio_url"), // URL to audio files
  isLocked: boolean("is_locked").notNull().default(true),
});

export const userProgress = pgTable("user_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  lessonId: varchar("lesson_id").references(() => lessons.id).notNull(),
  isCompleted: boolean("is_completed").notNull().default(false),
  completedAt: timestamp("completed_at"),
  score: integer("score").default(0), // Percentage score
  attempts: integer("attempts").notNull().default(0),
});

export const achievements = pgTable("achievements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(), // FontAwesome icon class
  color: text("color").notNull(),
  requirement: jsonb("requirement").notNull(), // Achievement requirements
  xpReward: integer("xp_reward").notNull().default(100),
});

export const userAchievements = pgTable("user_achievements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  achievementId: varchar("achievement_id").references(() => achievements.id).notNull(),
  unlockedAt: timestamp("unlocked_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
});

// For Replit Auth upsert operations
export const upsertUserSchema = createInsertSchema(users).pick({
  id: true,
  email: true,
  firstName: true,
  lastName: true,
  profileImageUrl: true,
});

export const insertUnitSchema = createInsertSchema(units).pick({
  name: true,
  description: true,
  orderIndex: true,
  color: true,
});

export const insertLessonSchema = createInsertSchema(lessons).pick({
  unitId: true,
  name: true,
  description: true,
  orderIndex: true,
  content: true,
  audioUrl: true,
});

export const insertProgressSchema = createInsertSchema(userProgress).pick({
  userId: true,
  lessonId: true,
  score: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertUnit = z.infer<typeof insertUnitSchema>;
export type Unit = typeof units.$inferSelect;

export type InsertLesson = z.infer<typeof insertLessonSchema>;
export type Lesson = typeof lessons.$inferSelect;

export type InsertProgress = z.infer<typeof insertProgressSchema>;
export type UserProgress = typeof userProgress.$inferSelect;

export type Achievement = typeof achievements.$inferSelect;
export type UserAchievement = typeof userAchievements.$inferSelect;
