import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertProgressSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let user = await storage.getUser(userId);
      
      // If user doesn't exist in our learning system, create them
      if (!user) {
        user = await storage.upsertUser({
          id: userId,
          email: req.user.claims.email || null,
          firstName: req.user.claims.first_name || null,
          lastName: req.user.claims.last_name || null,
          profileImageUrl: req.user.claims.profile_image_url || null,
        });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });
  // User routes
  app.get("/api/user/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  app.put("/api/user/:id", async (req, res) => {
    try {
      const user = await storage.updateUser(req.params.id, req.body);
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  // Units and lessons
  app.get("/api/units", async (req, res) => {
    try {
      const units = await storage.getAllUnits();
      res.json(units);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch units" });
    }
  });

  app.get("/api/units/:id/lessons", async (req, res) => {
    try {
      const lessons = await storage.getLessonsByUnitId(req.params.id);
      res.json(lessons);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch lessons" });
    }
  });

  app.get("/api/lessons/:id", async (req, res) => {
    try {
      const lesson = await storage.getLessonById(req.params.id);
      if (!lesson) {
        return res.status(404).json({ error: "Lesson not found" });
      }
      res.json(lesson);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch lesson" });
    }
  });

  // Progress tracking
  app.get("/api/user/:userId/progress", async (req, res) => {
    try {
      const progress = await storage.getUserProgress(req.params.userId);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch progress" });
    }
  });

  app.post("/api/progress", async (req, res) => {
    try {
      const validatedData = insertProgressSchema.parse(req.body);
      const progress = await storage.updateProgress(validatedData);
      
      // Update user stats
      let user = await storage.getUser(validatedData.userId);
      
      // Handle demo-user fallback
      if (!user && validatedData.userId === "demo-user") {
        user = await storage.createUser({
          email: "demo@violinmaster.com",
          username: "demo-user",
        });
      }
      
      if (user && progress.isCompleted) {
        // Only increment if this is the first completion
        const existingProgress = await storage.getUserProgressForLesson(validatedData.userId, validatedData.lessonId);
        const isFirstCompletion = !existingProgress || !existingProgress.isCompleted;
        
        const updatedUser = await storage.updateUser(user.id, {
          lessonsCompleted: isFirstCompletion ? user.lessonsCompleted + 1 : user.lessonsCompleted,
          totalXp: user.totalXp + (isFirstCompletion ? 50 : 10), // 50 XP for first completion, 10 for retakes
        });
        res.json({ progress, user: updatedUser });
      } else {
        res.json({ progress });
      }
    } catch (error) {
      console.error("Progress update error:", error);
      res.status(500).json({ error: "Failed to update progress" });
    }
  });

  // Achievements
  app.get("/api/achievements", async (req, res) => {
    try {
      const achievements = await storage.getAllAchievements();
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch achievements" });
    }
  });

  app.get("/api/user/:userId/achievements", async (req, res) => {
    try {
      const userAchievements = await storage.getUserAchievements(req.params.userId);
      const achievements = await storage.getAllAchievements();
      
      const result = achievements.map(achievement => ({
        ...achievement,
        unlocked: userAchievements.some(ua => ua.achievementId === achievement.id),
        unlockedAt: userAchievements.find(ua => ua.achievementId === achievement.id)?.unlockedAt,
      }));
      
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user achievements" });
    }
  });

  // Practice session
  app.post("/api/practice", async (req, res) => {
    try {
      const { userId, minutes } = req.body;
      let user = await storage.getUser(userId);
      
      // Handle demo-user fallback
      if (!user && userId === "demo-user") {
        user = await storage.createUser({
          email: "demo@violinmaster.com",
          username: "demo-user",
        });
      }
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const today = new Date().toISOString().split('T')[0];
      const lastPracticeDay = user.lastPracticeDate ? new Date(user.lastPracticeDate).toISOString().split('T')[0] : null;
      const isNewDay = lastPracticeDay !== today;

      // Calculate streak properly
      let newStreak = user.currentStreak;
      if (isNewDay) {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayStr = yesterday.toISOString().split('T')[0];
        
        if (lastPracticeDay === yesterdayStr) {
          // Practiced yesterday, continue streak
          newStreak = user.currentStreak + 1;
        } else {
          // Start new streak
          newStreak = 1;
        }
      }

      const updatedUser = await storage.updateUser(userId, {
        totalXp: user.totalXp + minutes * 10, // 10 XP per minute
        practiceTimeMinutes: user.practiceTimeMinutes + minutes,
        todayPracticeMinutes: isNewDay ? minutes : user.todayPracticeMinutes + minutes,
        currentStreak: newStreak,
        longestStreak: Math.max(user.longestStreak, newStreak),
        lastPracticeDate: new Date().toISOString().split('T')[0],
      });

      res.json(updatedUser);
    } catch (error) {
      console.error("Practice session error:", error);
      res.status(500).json({ error: "Failed to update practice session" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
