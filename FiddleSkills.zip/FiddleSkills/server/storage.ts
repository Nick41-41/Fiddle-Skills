import {
  users,
  units,
  lessons,
  userProgress,
  achievements,
  userAchievements,
  type User,
  type InsertUser,
  type UpsertUser,
  type Unit,
  type InsertUnit,
  type Lesson,
  type InsertLesson,
  type UserProgress,
  type InsertProgress,
  type Achievement,
  type UserAchievement,
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User>;
  // Required for Replit Auth
  upsertUser(user: UpsertUser): Promise<User>;

  // Units and lessons
  getAllUnits(): Promise<Unit[]>;
  getLessonsByUnitId(unitId: string): Promise<Lesson[]>;
  getLessonById(id: string): Promise<Lesson | undefined>;

  // Progress tracking
  getUserProgress(userId: string): Promise<UserProgress[]>;
  getUserProgressForLesson(userId: string, lessonId: string): Promise<UserProgress | undefined>;
  updateProgress(progress: InsertProgress): Promise<UserProgress>;

  // Achievements
  getAllAchievements(): Promise<Achievement[]>;
  getUserAchievements(userId: string): Promise<UserAchievement[]>;
  unlockAchievement(userId: string, achievementId: string): Promise<UserAchievement>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private units: Map<string, Unit>;
  private lessons: Map<string, Lesson>;
  private userProgress: Map<string, UserProgress>;
  private achievements: Map<string, Achievement>;
  private userAchievements: Map<string, UserAchievement>;

  constructor() {
    this.users = new Map();
    this.units = new Map();
    this.lessons = new Map();
    this.userProgress = new Map();
    this.achievements = new Map();
    this.userAchievements = new Map();
    this.seedData();
  }

  private seedData() {
    // Create initial units
    const unit1: Unit = {
      id: "unit-1",
      name: "Violin Basics",
      description: "Learn the fundamentals of violin playing",
      orderIndex: 1,
      color: "blue",
      isLocked: false,
    };

    const unit2: Unit = {
      id: "unit-2", 
      name: "Basic Bow Techniques",
      description: "Master essential bowing techniques",
      orderIndex: 2,
      color: "green",
      isLocked: false,
    };

    this.units.set(unit1.id, unit1);
    this.units.set(unit2.id, unit2);

    // Create lessons for unit 1
    const lesson1: Lesson = {
      id: "lesson-1",
      unitId: "unit-1",
      name: "Holding the Violin",
      description: "Learn proper violin posture and hold",
      orderIndex: 1,
      xpReward: 50,
      content: {
        type: "theory",
        sections: [
          {
            title: "Violin Posture",
            content: "Place the violin on your left shoulder and support it with your chin.",
            quiz: {
              question: "Where should you place the violin?",
              options: ["On your right shoulder", "On your left shoulder", "In front of your chest"],
              correct: 1
            }
          }
        ]
      },
      audioUrl: "/audio/holding-violin.mp3",
      isLocked: false,
    };

    const lesson2: Lesson = {
      id: "lesson-2",
      unitId: "unit-2",
      name: "Holding the Bow",
      description: "Master the correct bow grip",
      orderIndex: 1,
      xpReward: 50,
      content: {
        type: "theory",
        sections: [
          {
            title: "Bow Grip",
            content: "Hold the bow with a relaxed grip using your thumb and fingers.",
            quiz: {
              question: "What kind of grip should you use?",
              options: ["Tight grip", "Relaxed grip", "No grip"],
              correct: 1
            }
          }
        ]
      },
      audioUrl: "/audio/bow-grip.mp3",
      isLocked: false,
    };

    const lesson3: Lesson = {
      id: "lesson-3",
      unitId: "unit-2",
      name: "Bow Speed Control",
      description: "Learn smooth bowing technique",
      orderIndex: 2,
      xpReward: 50,
      content: {
        type: "practice",
        sections: [
          {
            title: "Understanding Bow Speed",
            content: "Bow speed controls the volume and tone quality of your violin. Slower bow speeds create quieter, more controlled sounds.",
            quiz: {
              question: "What does bow speed control?",
              options: ["Pitch only", "Volume and tone quality", "String tension"],
              correct: 1
            }
          },
          {
            title: "Practice Bow Speed",
            content: "Now let's practice controlling bow speed. Start with slow, controlled movements.",
            practice: {
              type: "bow_speed",
              instructions: "Use the slider to control bow speed, then play the note"
            }
          }
        ]
      },
      audioUrl: "/audio/bow-speed.mp3",
      isLocked: false,
    };

    const lesson4: Lesson = {
      id: "lesson-4",
      unitId: "unit-1",
      name: "Reading Music Notation",
      description: "Learn to read basic violin music",
      orderIndex: 2,
      xpReward: 50,
      content: {
        type: "theory",
        sections: [
          {
            title: "The Violin Clef",
            content: "Violin music is written in treble clef. The lines from bottom to top are E, G, B, D, F. Remember: Every Good Boy Does Fine!",
            quiz: {
              question: "What is the bottom line of the treble clef?",
              options: ["G", "E", "F"],
              correct: 1
            }
          },
          {
            title: "Note Values",
            content: "Different note shapes represent different durations. A whole note lasts 4 beats, a half note lasts 2 beats, and a quarter note lasts 1 beat.",
            quiz: {
              question: "How many beats does a half note last?",
              options: ["1 beat", "2 beats", "4 beats"],
              correct: 1
            }
          }
        ]
      },
      audioUrl: "/audio/music-notation.mp3",
      isLocked: true,
    };

    const lesson5: Lesson = {
      id: "lesson-5",
      unitId: "unit-1",
      name: "First Notes: Open Strings",
      description: "Play your first violin notes",
      orderIndex: 3,
      xpReward: 75,
      content: {
        type: "practice",
        sections: [
          {
            title: "Open String Names",
            content: "The four open strings of the violin are G (lowest), D, A, and E (highest). Each string produces a different pitch when played without pressing any fingers.",
            quiz: {
              question: "Which is the highest pitched open string?",
              options: ["G string", "A string", "E string"],
              correct: 2
            }
          },
          {
            title: "Playing Open Strings",
            content: "Start with the E string (thinnest). Use your bow to create smooth, even strokes across the string.",
            practice: {
              type: "open_strings",
              instructions: "Click on each string to hear its sound, then try to play it"
            }
          }
        ]
      },
      audioUrl: "/audio/open-strings.mp3",
      isLocked: true,
    };

    this.lessons.set(lesson1.id, lesson1);
    this.lessons.set(lesson2.id, lesson2);
    this.lessons.set(lesson3.id, lesson3);
    this.lessons.set(lesson4.id, lesson4);
    this.lessons.set(lesson5.id, lesson5);

    // Create achievements
    const achievements: Achievement[] = [
      {
        id: "first-week",
        name: "First Week!",
        description: "7 day streak",
        icon: "fas fa-medal",
        color: "yellow",
        requirement: { type: "streak", value: 7 },
        xpReward: 100,
      },
      {
        id: "note-perfect",
        name: "Note Perfect",
        description: "10 correct notes in a row",
        icon: "fas fa-music",
        color: "green", 
        requirement: { type: "streak_correct", value: 10 },
        xpReward: 150,
      },
      {
        id: "quick-learner",
        name: "Quick Learner",
        description: "Completed 5 lessons",
        icon: "fas fa-graduation-cap",
        color: "blue",
        requirement: { type: "lessons_completed", value: 5 },
        xpReward: 200,
      },
    ];

    achievements.forEach(achievement => {
      this.achievements.set(achievement.id, achievement);
    });

    // Create demo user
    const demoUser: User = {
      id: "demo-user",
      email: "demo@violinmaster.com",
      firstName: null,
      lastName: null,
      profileImageUrl: null,
      username: "ViolinLearner",
      totalXp: 1250,
      currentStreak: 7,
      longestStreak: 10,
      lessonsCompleted: 1,
      practiceTimeMinutes: 150,
      currentLevel: 2,
      dailyGoalMinutes: 20,
      todayPracticeMinutes: 15,
      lastPracticeDate: new Date().toISOString().split('T')[0],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.users.set(demoUser.id, demoUser);

    // Create progress for demo user
    const progress1: UserProgress = {
      id: "progress-1",
      userId: "demo-user",
      lessonId: "lesson-1",
      isCompleted: true,
      completedAt: new Date(),
      score: 100,
      attempts: 1,
    };

    const progress2: UserProgress = {
      id: "progress-2", 
      userId: "demo-user",
      lessonId: "lesson-2",
      isCompleted: true,
      completedAt: new Date(),
      score: 100,
      attempts: 1,
    };

    this.userProgress.set(progress1.id, progress1);
    this.userProgress.set(progress2.id, progress2);

    // Unlock some achievements for demo user
    const userAchievement: UserAchievement = {
      id: "user-ach-1",
      userId: "demo-user",
      achievementId: "first-week",
      unlockedAt: new Date(),
    };

    this.userAchievements.set(userAchievement.id, userAchievement);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      email: insertUser.email || null,
      firstName: null,
      lastName: null,
      profileImageUrl: null,
      totalXp: 0,
      currentStreak: 0,
      longestStreak: 0,
      lessonsCompleted: 0,
      practiceTimeMinutes: 0,
      currentLevel: 1,
      dailyGoalMinutes: 20,
      todayPracticeMinutes: 0,
      lastPracticeDate: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    let user = this.users.get(userData.id!);
    if (user) {
      // Update existing user
      user = { ...user, ...userData, updatedAt: new Date() };
      this.users.set(userData.id!, user);
      return user;
    } else {
      // Create new user
      const newUser: User = {
        ...userData,
        id: userData.id!,
        email: userData.email || null,
        username: null,
        totalXp: 0,
        currentStreak: 0,
        longestStreak: 0,
        lessonsCompleted: 0,
        practiceTimeMinutes: 0,
        currentLevel: 1,
        dailyGoalMinutes: 20,
        todayPracticeMinutes: 0,
        lastPracticeDate: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.users.set(newUser.id, newUser);
      return newUser;
    }
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User> {
    const user = this.users.get(id);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUnits(): Promise<Unit[]> {
    return Array.from(this.units.values()).sort((a, b) => a.orderIndex - b.orderIndex);
  }

  async getLessonsByUnitId(unitId: string): Promise<Lesson[]> {
    return Array.from(this.lessons.values())
      .filter(lesson => lesson.unitId === unitId)
      .sort((a, b) => a.orderIndex - b.orderIndex);
  }

  async getLessonById(id: string): Promise<Lesson | undefined> {
    return this.lessons.get(id);
  }

  async getUserProgress(userId: string): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(progress => progress.userId === userId);
  }

  async getUserProgressForLesson(userId: string, lessonId: string): Promise<UserProgress | undefined> {
    return Array.from(this.userProgress.values()).find(
      progress => progress.userId === userId && progress.lessonId === lessonId
    );
  }

  async updateProgress(progressData: InsertProgress): Promise<UserProgress> {
    const existing = await this.getUserProgressForLesson(progressData.userId, progressData.lessonId);
    
    if (existing) {
      const updated = { 
        ...existing, 
        score: progressData.score || 0,
        attempts: existing.attempts + 1,
        isCompleted: (progressData.score || 0) >= 80,
        completedAt: (progressData.score || 0) >= 80 ? new Date() : existing.completedAt,
      };
      this.userProgress.set(existing.id, updated);
      return updated;
    } else {
      const id = randomUUID();
      const progress: UserProgress = {
        id,
        userId: progressData.userId,
        lessonId: progressData.lessonId,
        isCompleted: (progressData.score || 0) >= 80,
        completedAt: (progressData.score || 0) >= 80 ? new Date() : null,
        score: progressData.score || 0,
        attempts: 1,
      };
      this.userProgress.set(id, progress);
      return progress;
    }
  }

  async getAllAchievements(): Promise<Achievement[]> {
    return Array.from(this.achievements.values());
  }

  async getUserAchievements(userId: string): Promise<UserAchievement[]> {
    return Array.from(this.userAchievements.values()).filter(ua => ua.userId === userId);
  }

  async unlockAchievement(userId: string, achievementId: string): Promise<UserAchievement> {
    const id = randomUUID();
    const userAchievement: UserAchievement = {
      id,
      userId,
      achievementId,
      unlockedAt: new Date(),
    };
    this.userAchievements.set(id, userAchievement);
    return userAchievement;
  }
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    if (!email) return undefined;
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        totalXp: 0,
        currentStreak: 0,
        longestStreak: 0,
        lessonsCompleted: 0,
        practiceTimeMinutes: 0,
        currentLevel: 1,
        dailyGoalMinutes: 20,
        todayPracticeMinutes: 0,
        lastPracticeDate: null,
      })
      .returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        // Set defaults for learning data on first time users
        totalXp: 0,
        currentStreak: 0,
        longestStreak: 0,
        lessonsCompleted: 0,
        practiceTimeMinutes: 0,
        currentLevel: 1,
        dailyGoalMinutes: 20,
        todayPracticeMinutes: 0,
        lastPracticeDate: null,
      })
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getAllUnits(): Promise<Unit[]> {
    const result = await db.select().from(units).orderBy(units.orderIndex);
    return result;
  }

  async getLessonsByUnitId(unitId: string): Promise<Lesson[]> {
    const result = await db
      .select()
      .from(lessons)
      .where(eq(lessons.unitId, unitId))
      .orderBy(lessons.orderIndex);
    return result;
  }

  async getLessonById(id: string): Promise<Lesson | undefined> {
    const [lesson] = await db.select().from(lessons).where(eq(lessons.id, id));
    return lesson || undefined;
  }

  async getUserProgress(userId: string): Promise<UserProgress[]> {
    const result = await db
      .select()
      .from(userProgress)
      .where(eq(userProgress.userId, userId));
    return result;
  }

  async getUserProgressForLesson(userId: string, lessonId: string): Promise<UserProgress | undefined> {
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(and(eq(userProgress.userId, userId), eq(userProgress.lessonId, lessonId)));
    return progress || undefined;
  }

  async updateProgress(progressData: InsertProgress): Promise<UserProgress> {
    const existing = await this.getUserProgressForLesson(progressData.userId, progressData.lessonId);
    
    if (existing) {
      const [updated] = await db
        .update(userProgress)
        .set({
          score: progressData.score || 0,
          attempts: existing.attempts + 1,
          isCompleted: (progressData.score || 0) >= 80,
          completedAt: (progressData.score || 0) >= 80 ? new Date() : existing.completedAt,
        })
        .where(eq(userProgress.id, existing.id))
        .returning();
      return updated;
    } else {
      const [progress] = await db
        .insert(userProgress)
        .values({
          userId: progressData.userId,
          lessonId: progressData.lessonId,
          isCompleted: (progressData.score || 0) >= 80,
          completedAt: (progressData.score || 0) >= 80 ? new Date() : null,
          score: progressData.score || 0,
          attempts: 1,
        })
        .returning();
      return progress;
    }
  }

  async getAllAchievements(): Promise<Achievement[]> {
    const result = await db.select().from(achievements);
    return result;
  }

  async getUserAchievements(userId: string): Promise<UserAchievement[]> {
    const result = await db
      .select()
      .from(userAchievements)
      .where(eq(userAchievements.userId, userId));
    return result;
  }

  async unlockAchievement(userId: string, achievementId: string): Promise<UserAchievement> {
    const [userAchievement] = await db
      .insert(userAchievements)
      .values({
        userId,
        achievementId,
        unlockedAt: new Date(),
      })
      .returning();
    return userAchievement;
  }
}

// Use memory storage for development, database for production
export const storage = process.env.DATABASE_URL ? new DatabaseStorage() : new MemStorage();
