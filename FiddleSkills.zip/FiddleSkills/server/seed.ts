import { db } from "./db";
import { units, lessons, achievements, users, userProgress, userAchievements } from "@shared/schema";

export async function seedDatabase() {
  try {
    // Clear existing data for reseeding (only lessons and units for new content)
    console.log("Clearing lessons and units for reseeding...");
    await db.delete(userProgress);
    await db.delete(userAchievements);
    await db.delete(lessons);
    await db.delete(units);
    await db.delete(achievements);

    console.log("Seeding database...");

    // Create demo user first
    await db.insert(users).values({
      id: "demo-user",
      email: "demo@violinmaster.com",
      username: "demo-user",
      firstName: "Demo",
      lastName: "User",
      totalXp: 150,
      currentStreak: 3,
      longestStreak: 5,
      lessonsCompleted: 2,
      practiceTimeMinutes: 45,
      currentLevel: 2,
      dailyGoalMinutes: 20,
      todayPracticeMinutes: 15,
      lastPracticeDate: new Date().toISOString().split('T')[0],
    }).onConflictDoNothing();

    // Create units
    const [unit1] = await db.insert(units).values({
      id: "unit-1",
      name: "Violin Basics",
      description: "Learn the fundamentals of violin playing",
      orderIndex: 1,
      color: "blue",
      isLocked: false,
    }).returning();

    const [unit2] = await db.insert(units).values({
      id: "unit-2", 
      name: "Basic Bow Techniques",
      description: "Master essential bowing techniques",
      orderIndex: 2,
      color: "green",
      isLocked: false,
    }).returning();

    // Create lessons for unit 1
    await db.insert(lessons).values([
      {
        id: "lesson-1",
        unitId: unit1.id,
        name: "Holding the Violin",
        description: "Learn proper violin posture and hold",
        orderIndex: 1,
        xpReward: 50,
        content: {
          type: "theory",
          sections: [
            {
              title: "Proper Violin Position",
              content: "Place the violin on your left shoulder and support it with your chin. The violin should rest securely without requiring your left hand to hold it up.",
              imageUrl: "/src/assets/generated_images/Violin_holding_position_guide_3c0bbf8c.png",
              quiz: {
                question: "Where should you place the violin?",
                options: ["On your right shoulder", "On your left shoulder", "In front of your chest"],
                correct: 1
              }
            },
            {
              title: "Head and Neck Position",
              content: "Keep your head slightly tilted to the left, with your chin resting on the chin rest. Your neck should be relaxed and natural - don't crane your neck too far.",
              quiz: {
                question: "How should your head be positioned?",
                options: ["Straight ahead", "Slightly tilted left", "Tilted far to the right"],
                correct: 1
              }
            }
          ]
        },
        audioUrl: "/audio/holding-violin.mp3",
        isLocked: false,
      },
      {
        id: "lesson-4",
        unitId: unit1.id,
        name: "Reading Music Notation",
        description: "Learn to read basic violin music",
        orderIndex: 2,
        xpReward: 50,
        content: {
          type: "theory",
          sections: [
            {
              title: "The Violin Clef",
              content: "Violin music is written in treble clef. The lines from bottom to top are E, G, B, D, F. Remember: Every Good Boy Does Fine!",
              quiz: {
                question: "What is the bottom line of the treble clef?",
                options: ["G", "E", "F"],
                correct: 1
              }
            },
            {
              title: "Note Values",
              content: "Different note shapes represent different durations. A whole note lasts 4 beats, a half note lasts 2 beats, and a quarter note lasts 1 beat.",
              quiz: {
                question: "How many beats does a half note last?",
                options: ["1 beat", "2 beats", "4 beats"],
                correct: 1
              }
            }
          ]
        },
        audioUrl: "/audio/music-notation.mp3",
        isLocked: true,
      },
      {
        id: "lesson-5",
        unitId: unit1.id,
        name: "First Notes: Open Strings",
        description: "Play your first violin notes",
        orderIndex: 3,
        xpReward: 75,
        content: {
          type: "practice",
          sections: [
            {
              title: "Open String Names",
              content: "The four open strings of the violin are G (lowest), D, A, and E (highest). Each string produces a different pitch when played without pressing any fingers.",
              quiz: {
                question: "Which is the highest pitched open string?",
                options: ["G string", "A string", "E string"],
                correct: 2
              }
            },
            {
              title: "Playing Open Strings",
              content: "Start with the E string (thinnest). Use your bow to create smooth, even strokes across the string.",
              practice: {
                type: "open_strings",
                instructions: "Click on each string to hear its sound, then try to play it"
              }
            }
          ]
        },
        audioUrl: "/audio/open-strings.mp3",
        isLocked: true,
      },
      {
        id: "lesson-2",
        unitId: unit1.id,
        name: "Holding the Bow",
        description: "Master the proper bow grip technique",
        orderIndex: 2,
        xpReward: 50,
        content: {
          type: "theory",
          sections: [
            {
              title: "Bow Grip Fundamentals",
              content: "Place your thumb on the underside of the frog (the black part at the bottom). Your thumb should be slightly bent and positioned opposite your middle finger.",
              imageUrl: "/src/assets/generated_images/Violin_bow_grip_technique_3485898b.png",
              quiz: {
                question: "Where should your thumb be placed on the bow?",
                options: ["On the tip", "On the frog (bottom part)", "In the middle"],
                correct: 1
              }
            },
            {
              title: "Finger Placement",
              content: "Your index finger should curve over the bow grip. Middle and ring fingers rest on top, while your pinky sits on top of the bow stick. Keep all fingers curved and relaxed.",
              quiz: {
                question: "Which finger should curve over the bow grip?",
                options: ["Thumb", "Index finger", "Pinky"],
                correct: 1
              }
            }
          ]
        },
        audioUrl: "/audio/bow-hold.mp3",
        isLocked: true,
      },
      {
        id: "lesson-3",
        unitId: unit1.id,
        name: "Standing and Sitting Posture",
        description: "Learn proper body posture for violin playing",
        orderIndex: 4,
        xpReward: 40,
        content: {
          type: "theory",
          sections: [
            {
              title: "Standing Position",
              content: "Stand with feet shoulder-width apart, weight evenly distributed. Keep your back straight but relaxed. Your left foot can be slightly forward for better balance.",
              quiz: {
                question: "How should your feet be positioned when standing?",
                options: ["Together", "Shoulder-width apart", "One behind the other"],
                correct: 1
              }
            },
            {
              title: "Sitting Position",
              content: "Sit on the front half of the chair with both feet flat on the floor. Keep your back straight and avoid leaning back. The violin position remains the same as when standing.",
              quiz: {
                question: "When sitting, where should you position yourself on the chair?",
                options: ["Back of the chair", "Front half of the chair", "Exact center"],
                correct: 1
              }
            }
          ]
        },
        audioUrl: "/audio/posture.mp3",
        isLocked: true,
      }
    ]);

    // Create lessons for unit 2
    await db.insert(lessons).values([
      {
        id: "lesson-2-1",
        unitId: unit2.id,
        name: "Basic Bow Strokes",
        description: "Learn fundamental bowing techniques",
        orderIndex: 1,
        xpReward: 60,
        content: {
          type: "practice",
          sections: [
            {
              title: "Down Bow and Up Bow",
              content: "A down bow moves from frog to tip, while an up bow moves from tip to frog. Start with down bows as they feel more natural.",
              quiz: {
                question: "Which direction does a down bow move?",
                options: ["Tip to frog", "Frog to tip", "Side to side"],
                correct: 1
              }
            },
            {
              title: "Straight Bow Practice",
              content: "Keep your bow perpendicular to the strings. Focus on smooth, even pressure throughout the stroke.",
              practice: {
                type: "bowing",
                instructions: "Practice straight bow strokes on open strings. Use the bow speed control to find a comfortable tempo."
              }
            }
          ]
        },
        audioUrl: "/audio/bow-strokes.mp3",
        isLocked: false,
      },
      {
        id: "lesson-2-2",
        unitId: unit2.id,
        name: "Bow Speed and Pressure",
        description: "Control your bow dynamics",
        orderIndex: 2,
        xpReward: 70,
        content: {
          type: "practice",
          sections: [
            {
              title: "Controlling Bow Speed",
              content: "Slow bows create a fuller sound, while faster bows create a lighter tone. Practice varying your bow speed while maintaining consistent pressure.",
              practice: {
                type: "bowing",
                instructions: "Try different bow speeds using the slider. Notice how the sound changes."
              }
            },
            {
              title: "Bow Pressure",
              content: "Too much pressure creates a harsh, scratchy sound. Too little creates a weak, airy tone. Find the sweet spot with moderate, consistent pressure.",
              quiz: {
                question: "What happens when you use too much bow pressure?",
                options: ["Sweet, clear tone", "Harsh, scratchy sound", "No sound at all"],
                correct: 1
              }
            }
          ]
        },
        audioUrl: "/audio/bow-dynamics.mp3",
        isLocked: true,
      },
      {
        id: "lesson-2-3",
        unitId: unit2.id,
        name: "String Crossing",
        description: "Move smoothly between strings",
        orderIndex: 3,
        xpReward: 80,
        content: {
          type: "practice",
          sections: [
            {
              title: "Adjacent String Crossing",
              content: "Practice moving between adjacent strings (G-D, D-A, A-E). Keep your bow arm level and make small adjustments with your elbow.",
              practice: {
                type: "string_crossing",
                instructions: "Click between adjacent strings smoothly. Focus on keeping the bow perpendicular."
              }
            },
            {
              title: "Non-Adjacent Strings",
              content: "Moving between non-adjacent strings (G-A, D-E) requires larger arm movements. Practice slowly to develop muscle memory.",
              quiz: {
                question: "Which requires larger arm movements?",
                options: ["Adjacent string crossing", "Non-adjacent string crossing", "Both are the same"],
                correct: 1
              }
            }
          ]
        },
        audioUrl: "/audio/string-crossing.mp3",
        isLocked: true,
      }
    ]);

    // Create achievements
    await db.insert(achievements).values([
      {
        id: "first-week",
        name: "First Week!",
        description: "7 day streak",
        icon: "fas fa-medal",
        color: "yellow",
        requirement: { type: "streak", value: 7 },
        xpReward: 100,
      },
      {
        id: "note-perfect",
        name: "Note Perfect",
        description: "10 correct notes in a row",
        icon: "fas fa-music",
        color: "green", 
        requirement: { type: "streak_correct", value: 10 },
        xpReward: 150,
      },
      {
        id: "quick-learner",
        name: "Quick Learner",
        description: "Completed 5 lessons",
        icon: "fas fa-graduation-cap",
        color: "blue",
        requirement: { type: "lessons_completed", value: 5 },
        xpReward: 200,
      },
    ]);

    console.log("Database seeded successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}