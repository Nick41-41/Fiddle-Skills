import { AppHeader } from "@/components/app-header";
import { MainNavigation } from "@/components/main-navigation";
import { LessonPath } from "@/components/lesson-path";
import { Sidebar } from "@/components/sidebar";

export default function Home() {
  return (
    <div className="bg-duo-light min-h-screen">
      <AppHeader />
      <MainNavigation activeTab="learn" />
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <LessonPath />
          </div>
          <div>
            <Sidebar />
          </div>
        </div>
      </main>
    </div>
  );
}
