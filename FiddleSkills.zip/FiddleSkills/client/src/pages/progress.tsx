import { AppHeader } from "@/components/app-header";
import { MainNavigation } from "@/components/main-navigation";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { type User } from "@shared/schema";

export default function ProgressPage() {
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user/demo-user"],
  });

  if (!user) {
    return <div>Loading...</div>;
  }

  const progressPercentage = Math.min((user.lessonsCompleted / 5) * 100, 100); // 5 total lessons available
  const todayProgressPercentage = (user.todayPracticeMinutes / user.dailyGoalMinutes) * 100;

  return (
    <div className="bg-duo-light min-h-screen">
      <AppHeader />
      <MainNavigation activeTab="progress" />
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-duo-gray mb-2">Your Progress</h1>
          <p className="text-gray-600">Track your violin learning journey</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <Card data-testid="stats-total-xp">
            <CardHeader>
              <CardTitle className="text-center">Total XP</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <div className="text-4xl font-bold text-duo-blue mb-2" data-testid="text-total-xp">
                  {user.totalXp.toLocaleString()}
                </div>
                <p className="text-gray-600">Experience Points</p>
              </div>
            </CardContent>
          </Card>

          <Card data-testid="stats-streak">
            <CardHeader>
              <CardTitle className="text-center">Current Streak</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <div className="text-4xl font-bold text-duo-orange mb-2 flex items-center justify-center" data-testid="text-current-streak">
                  {user.currentStreak} <i className="fas fa-fire ml-2"></i>
                </div>
                <p className="text-gray-600">Days in a row</p>
              </div>
            </CardContent>
          </Card>

          <Card data-testid="stats-lessons">
            <CardHeader>
              <CardTitle className="text-center">Lessons Completed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <div className="text-4xl font-bold text-duo-green mb-2" data-testid="text-lessons-completed">
                  {user.lessonsCompleted}
                </div>
                <p className="text-gray-600">Out of 5 available</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card data-testid="card-overall-progress">
            <CardHeader>
              <CardTitle>Overall Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">Course Completion</span>
                    <span className="text-duo-green font-bold" data-testid="text-course-progress">
                      {Math.round(progressPercentage)}%
                    </span>
                  </div>
                  <Progress value={progressPercentage} className="h-3" data-testid="progress-course" />
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">Today's Goal</span>
                    <span className="text-duo-blue font-bold" data-testid="text-daily-progress">
                      {user.todayPracticeMinutes}/{user.dailyGoalMinutes} min
                    </span>
                  </div>
                  <Progress value={todayProgressPercentage} className="h-3" data-testid="progress-daily" />
                </div>

                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-duo-purple" data-testid="text-practice-time">
                      {(user.practiceTimeMinutes / 60).toFixed(1)}h
                    </div>
                    <p className="text-sm text-gray-600">Total Practice</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-duo-orange" data-testid="text-longest-streak">
                      {user.longestStreak}
                    </div>
                    <p className="text-sm text-gray-600">Longest Streak</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-level-info">
            <CardHeader>
              <CardTitle>Level Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-6">
                <div className="w-24 h-24 bg-duo-green rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl font-bold text-white" data-testid="text-current-level">
                    {user.currentLevel}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-duo-gray mb-2">
                  Level {user.currentLevel} Violinist
                </h3>
                <p className="text-gray-600">Keep practicing to reach Level {user.currentLevel + 1}!</p>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">XP to next level</span>
                  <span className="text-sm font-medium">{1500 - user.totalXp} XP</span>
                </div>
                <Progress value={(user.totalXp % 1000) / 10} className="h-2" data-testid="progress-next-level" />
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
