import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Music, Award, Calendar, Users } from "lucide-react";

export default function Landing() {
  return (
    <div className="bg-duo-light min-h-screen">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-duo-green to-duo-blue text-white">
        <div className="container mx-auto px-4 py-20">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl font-bold mb-6">
              Learn Violin Like Never Before
            </h1>
            <p className="text-xl mb-8 text-white/90">
              Master the violin with our gamified learning platform. Interactive lessons, 
              virtual practice tools, and progress tracking make learning fun and effective.
            </p>
            <Button 
              size="lg" 
              className="bg-white text-duo-green hover:bg-gray-100 text-lg px-8 py-4"
              onClick={() => window.location.href = "/api/login"}
              data-testid="button-login"
            >
              Start Learning Free
            </Button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">
            Why Choose ViolinMaster?
          </h2>
          <p className="text-gray-600 text-lg">
            Experience the most engaging way to learn violin with our proven methods
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="text-center">
            <CardHeader>
              <Music className="h-12 w-12 text-duo-green mx-auto mb-4" />
              <CardTitle>Interactive Lessons</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Learn with hands-on practice sessions and virtual violin tools
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Award className="h-12 w-12 text-duo-blue mx-auto mb-4" />
              <CardTitle>Achievements</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Unlock badges and earn XP as you progress through lessons
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Calendar className="h-12 w-12 text-duo-purple mx-auto mb-4" />
              <CardTitle>Daily Practice</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Build consistent practice habits with daily goals and streaks
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Users className="h-12 w-12 text-duo-orange mx-auto mb-4" />
              <CardTitle>Progress Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Monitor your improvement with detailed statistics and insights
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16">
          <Card className="bg-gradient-to-r from-duo-green/10 to-duo-blue/10 border-duo-green/20">
            <CardContent className="py-12">
              <h3 className="text-2xl font-bold text-gray-800 mb-4">
                Ready to Start Your Musical Journey?
              </h3>
              <p className="text-gray-600 mb-6">
                Join thousands of students learning violin with our interactive platform
              </p>
              <Button 
                size="lg"
                className="bg-duo-green hover:bg-duo-green/90 text-white"
                onClick={() => window.location.href = "/api/login"}
                data-testid="button-signup"
              >
                Get Started Now
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}