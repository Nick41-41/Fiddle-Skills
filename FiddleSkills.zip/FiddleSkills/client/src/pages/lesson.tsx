import { useState } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { type Lesson as LessonType, type UserProgress } from "@shared/schema";
import { AppHeader } from "@/components/app-header";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { getImageUrl } from "@/assets/images";

export default function Lesson() {
  const [, params] = useRoute("/lesson/:lessonId");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [currentSection, setCurrentSection] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswerCorrect, setIsAnswerCorrect] = useState<boolean | null>(null);
  const [bowSpeed, setBowSpeed] = useState(50);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playingString, setPlayingString] = useState<string | null>(null);

  const lessonId = params?.lessonId;

  const { data: lesson, isLoading } = useQuery<LessonType>({
    queryKey: [`/api/lessons/${lessonId}`],
    enabled: !!lessonId,
  });

  const { data: progress } = useQuery<UserProgress>({
    queryKey: [`/api/user/demo-user/progress`, lessonId],
    queryFn: async () => {
      const allProgress = await fetch(`/api/user/demo-user/progress`).then(r => r.json());
      return allProgress.find((p: UserProgress) => p.lessonId === lessonId);
    },
    enabled: !!lessonId,
    retry: false, // Don't retry if demo user doesn't exist yet
  });

  const completeLessonMutation = useMutation({
    mutationFn: async (score: number) => {
      return apiRequest("POST", "/api/progress", {
        userId: "demo-user",
        lessonId: lessonId,
        score,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/demo-user/progress"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/demo-user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      
      toast({
        title: "Lesson Complete!",
        description: `You earned 50 XP! Great job on completing "${lesson?.name}"`,
      });
      
      // Navigate back to home after short delay
      setTimeout(() => {
        setLocation("/");
      }, 2000);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "There was an issue completing the lesson. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (isLoading || !lesson) {
    return (
      <div className="bg-duo-light min-h-screen">
        <AppHeader />
        <div className="flex items-center justify-center h-96">
          <div className="text-center">
            <i className="fas fa-spinner fa-spin text-4xl text-duo-green mb-4"></i>
            <p className="text-gray-600">Loading lesson...</p>
          </div>
        </div>
      </div>
    );
  }

  const content = lesson.content as any;
  const sections = content.sections || [];
  const section = sections[currentSection];
  const progressPercentage = ((currentSection + 1) / sections.length) * 100;

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
    const currentQuiz = section?.quiz;
    if (currentQuiz) {
      setIsAnswerCorrect(answerIndex === currentQuiz.correct);
    }
  };

  const handleNext = () => {
    if (currentSection < sections.length - 1) {
      setCurrentSection(currentSection + 1);
      setSelectedAnswer(null);
      setIsAnswerCorrect(null);
    } else {
      // Complete lesson
      completeLessonMutation.mutate(100);
    }
  };

  const handlePrevious = () => {
    if (currentSection > 0) {
      setCurrentSection(currentSection - 1);
      setSelectedAnswer(null);
      setIsAnswerCorrect(null);
    }
  };

  const handlePlay = () => {
    setIsPlaying(true);
    setShowFeedback(true);
    
    // Simulate audio playback
    setTimeout(() => {
      setIsPlaying(false);
      setTimeout(() => {
        setShowFeedback(false);
      }, 2000);
    }, 1000);
  };

  const handleStringPlay = (stringName: string) => {
    setPlayingString(stringName);
    
    // Simulate string sound
    setTimeout(() => {
      setPlayingString(null);
    }, 1000);
  };

  const isQuizSection = section?.quiz;
  const isPracticeSection = section?.practice;
  const canContinue = isQuizSection ? (selectedAnswer !== null && isAnswerCorrect === true) : true;

  return (
    <div className="bg-duo-light min-h-screen">
      <AppHeader />
      
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Lesson Header */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                <Button
                  variant="ghost"
                  onClick={() => setLocation("/")}
                  className="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center"
                  data-testid="button-back-home"
                >
                  <i className="fas fa-arrow-left text-gray-600"></i>
                </Button>
                <div>
                  <h1 className="text-2xl font-bold text-duo-gray" data-testid="lesson-title">
                    {lesson.name}
                  </h1>
                  <p className="text-sm text-gray-600">
                    Section {currentSection + 1} of {sections.length}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="w-32 bg-gray-200 rounded-full h-3">
                  <Progress value={progressPercentage} className="h-3" data-testid="lesson-progress" />
                </div>
                <span className="text-sm text-gray-600">{Math.round(progressPercentage)}%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lesson Content */}
        <Card className="mb-6">
          <CardContent className="p-8">
            {section && (
              <div>
                <h2 className="text-xl font-bold text-duo-gray mb-4" data-testid="section-title">
                  {section.title}
                </h2>
                
                <div className="bg-white p-6 rounded-xl border border-gray-100 mb-6">
                  <p className="text-gray-700 mb-4 text-lg leading-relaxed" data-testid="section-content">
                    {section.content}
                  </p>
                  
                  {/* Display instructional image if available */}
                  {section.imageUrl && (
                    <div className="mt-4 mb-6 text-center">
                      <img 
                        src={getImageUrl(section.imageUrl)} 
                        alt={`Instructional diagram for ${section.title}`}
                        className="max-w-full h-auto rounded-lg shadow-md mx-auto border border-gray-200"
                        data-testid="section-image"
                      />
                    </div>
                  )}
                  
                  {/* Interactive Quiz */}
                  {isQuizSection && (
                    <div className="bg-duo-light p-6 rounded-lg border-2 border-gray-200">
                      <h3 className="font-semibold text-duo-gray mb-4 text-lg" data-testid="quiz-question">
                        {section.quiz.question}
                      </h3>
                      <div className="space-y-3">
                        {section.quiz.options.map((option: string, index: number) => (
                          <button
                            key={index}
                            onClick={() => handleAnswerSelect(index)}
                            className={`w-full p-4 text-left rounded-lg border-2 transition-all font-medium ${
                              selectedAnswer === index
                                ? "border-duo-green bg-duo-green bg-opacity-10 text-duo-gray"
                                : "border-gray-200 hover:border-duo-green hover:bg-duo-green hover:bg-opacity-5"
                            }`}
                            data-testid={`quiz-option-${index}`}
                          >
                            {option}
                          </button>
                        ))}
                      </div>
                      
                      {selectedAnswer !== null && isAnswerCorrect !== null && (
                        <div className={`mt-4 p-4 rounded-lg border ${
                          isAnswerCorrect 
                            ? "bg-duo-green bg-opacity-10 border-duo-green" 
                            : "bg-red-50 border-red-300"
                        }`}>
                          <div className={`flex items-center ${isAnswerCorrect ? "text-duo-green" : "text-red-600"}`}>
                            <i className={`fas ${isAnswerCorrect ? "fa-check-circle" : "fa-times-circle"} mr-2`}></i>
                            <span className="font-medium">
                              {isAnswerCorrect 
                                ? "Great choice! That's correct!" 
                                : "Not quite right. Try again!"
                              }
                            </span>
                          </div>
                          {!isAnswerCorrect && (
                            <p className="text-red-600 text-sm mt-2">
                              The correct answer is: {section.quiz.options[section.quiz.correct]}
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Practice Exercise */}
                  {isPracticeSection && (
                    <div className="bg-amber-50 p-6 rounded-xl border-2 border-amber-200">
                      <div className="text-center mb-6">
                        <h3 className="font-semibold text-duo-gray mb-2 text-lg">Practice Time!</h3>
                        <p className="text-gray-600 mb-4">
                          {section.practice.instructions}
                        </p>
                      </div>
                      
                      {/* Virtual Violin Interface */}
                      <div className="bg-white p-6 rounded-lg border border-amber-200 mb-4">
                        <div className="space-y-3 mb-6">
                          <div className="flex items-center space-x-3">
                            <span className="text-sm font-medium w-8">E</span>
                            <div 
                              className={`flex-1 h-3 rounded-full relative cursor-pointer transition-all ${
                                playingString === 'E' ? 'bg-duo-green animate-pulse' : 'bg-amber-200 hover:bg-amber-300'
                              }`}
                              onClick={() => handleStringPlay('E')}
                              data-testid="violin-string-e"
                            >
                              <div className="absolute top-0 left-1/4 w-6 h-6 bg-duo-blue rounded-full -translate-y-1.5 shadow-md"></div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <span className="text-sm font-medium w-8">A</span>
                            <div 
                              className={`flex-1 h-3 rounded-full cursor-pointer transition-all ${
                                playingString === 'A' ? 'bg-duo-green animate-pulse' : 'bg-amber-200 hover:bg-amber-300'
                              }`}
                              onClick={() => handleStringPlay('A')}
                              data-testid="violin-string-a"
                            ></div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <span className="text-sm font-medium w-8">D</span>
                            <div 
                              className={`flex-1 h-3 rounded-full cursor-pointer transition-all ${
                                playingString === 'D' ? 'bg-duo-green animate-pulse' : 'bg-amber-200 hover:bg-amber-300'
                              }`}
                              onClick={() => handleStringPlay('D')}
                              data-testid="violin-string-d"
                            ></div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <span className="text-sm font-medium w-8">G</span>
                            <div 
                              className={`flex-1 h-3 rounded-full cursor-pointer transition-all ${
                                playingString === 'G' ? 'bg-duo-green animate-pulse' : 'bg-amber-200 hover:bg-amber-300'
                              }`}
                              onClick={() => handleStringPlay('G')}
                              data-testid="violin-string-g"
                            ></div>
                          </div>
                        </div>
                      </div>
                      
                      {/* Bow Speed Control */}
                      <div className="mb-6">
                        <label className="block text-sm font-medium mb-3">Bow Speed</label>
                        <div className="flex items-center space-x-4">
                          <span className="text-sm">Slow</span>
                          <input
                            type="range"
                            min="1"
                            max="100"
                            value={bowSpeed}
                            onChange={(e) => setBowSpeed(Number(e.target.value))}
                            className="flex-1 h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                            data-testid="bow-speed-slider"
                          />
                          <span className="text-sm">Fast</span>
                        </div>
                        <p className="text-xs text-gray-500 mt-2 text-center" data-testid="bow-speed-value">
                          Speed: {bowSpeed}%
                        </p>
                      </div>
                      
                      {/* Play Button */}
                      <div className="text-center">
                        <Button 
                          onClick={handlePlay}
                          disabled={isPlaying}
                          className="w-20 h-20 bg-duo-green hover:bg-green-600 rounded-full text-2xl"
                          data-testid="button-practice-play"
                        >
                          <i className={`fas ${isPlaying ? 'fa-spinner fa-spin' : 'fa-play'}`}></i>
                        </Button>
                      </div>

                      {/* Practice Feedback */}
                      {showFeedback && (
                        <div className="text-center mt-6" data-testid="practice-feedback">
                          <div className="inline-flex items-center space-x-2 bg-duo-green bg-opacity-10 text-duo-green px-6 py-3 rounded-lg border border-duo-green">
                            <i className="fas fa-check-circle text-xl"></i>
                            <span className="font-medium">Perfect bow control! Well done!</span>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Navigation Buttons */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentSection === 0}
                data-testid="button-previous"
                className="px-6 py-3"
              >
                <i className="fas fa-arrow-left mr-2"></i>
                Previous
              </Button>
              
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <span>{currentSection + 1}</span>
                <span>/</span>
                <span>{sections.length}</span>
              </div>
              
              <Button
                onClick={handleNext}
                disabled={!canContinue || completeLessonMutation.isPending}
                className="bg-duo-green hover:bg-green-600 px-6 py-3"
                data-testid="button-continue"
              >
                {completeLessonMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Saving...
                  </>
                ) : currentSection === sections.length - 1 ? (
                  <>
                    Complete Lesson
                    <i className="fas fa-trophy ml-2"></i>
                  </>
                ) : (
                  <>
                    Continue
                    <i className="fas fa-arrow-right ml-2"></i>
                  </>
                )}
              </Button>
            </div>
            
            {/* Helpful Instructions */}
            {isQuizSection && selectedAnswer !== null && !isAnswerCorrect && (
              <div className="text-center mt-4 pt-4 border-t border-gray-200">
                <p className="text-sm text-gray-600">
                  💡 Select the correct answer to continue to the next section.
                </p>
              </div>
            )}
            
            {isPracticeSection && (
              <div className="text-center mt-4 pt-4 border-t border-gray-200">
                <p className="text-sm text-gray-600">
                  🎻 Click on the violin strings to hear their sounds, then use the play button to practice.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}