import { AppHeader } from "@/components/app-header";
import { MainNavigation } from "@/components/main-navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Practice() {
  return (
    <div className="bg-duo-light min-h-screen">
      <AppHeader />
      <MainNavigation activeTab="practice" />
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card data-testid="practice-scales">
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-music text-duo-green mr-2"></i>
                Scale Practice
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Practice major and minor scales</p>
              <Button className="w-full bg-duo-green hover:bg-green-600" data-testid="button-start-scales">
                Start Practice (5 min)
              </Button>
            </CardContent>
          </Card>

          <Card data-testid="practice-notes">
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-eye text-duo-blue mr-2"></i>
                Note Recognition
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Identify notes on the staff</p>
              <Button className="w-full bg-duo-blue hover:bg-blue-600" data-testid="button-start-notes">
                Start Practice
              </Button>
            </CardContent>
          </Card>

          <Card data-testid="practice-ear">
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-ear-listen text-duo-purple mr-2"></i>
                Ear Training
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">Develop your musical ear</p>
              <Button className="w-full bg-duo-purple hover:bg-purple-600" data-testid="button-start-ear">
                Start Practice
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
