import { AppHeader } from "@/components/app-header";
import { MainNavigation } from "@/components/main-navigation";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface AchievementWithStatus {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  xpReward: number;
  unlocked: boolean;
  unlockedAt?: string;
}

export default function Achievements() {
  const { data: achievements = [] } = useQuery<AchievementWithStatus[]>({
    queryKey: ["/api/user/demo-user/achievements"],
  });

  return (
    <div className="bg-duo-light min-h-screen">
      <AppHeader />
      <MainNavigation activeTab="achievements" />
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-duo-gray mb-2">Achievements</h1>
          <p className="text-gray-600">Unlock achievements as you learn and practice!</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {achievements.map((achievement) => (
            <Card
              key={achievement.id}
              className={`${
                achievement.unlocked
                  ? `bg-${achievement.color === "yellow" ? "duo-yellow" : achievement.color === "green" ? "duo-green" : "duo-blue"} bg-opacity-10 border-${achievement.color === "yellow" ? "duo-yellow" : achievement.color === "green" ? "duo-green" : "duo-blue"}`
                  : "bg-gray-100 border-gray-200 opacity-60"
              }`}
              data-testid={`achievement-${achievement.id}`}
            >
              <CardContent className="p-6 text-center">
                <div
                  className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                    achievement.unlocked
                      ? achievement.color === "yellow"
                        ? "bg-duo-yellow"
                        : achievement.color === "green"
                        ? "bg-duo-green"
                        : "bg-duo-blue"
                      : "bg-gray-300"
                  }`}
                >
                  <i className={`${achievement.icon} text-white text-xl`}></i>
                </div>
                <h3 className="font-bold text-lg mb-2 text-duo-gray">{achievement.name}</h3>
                <p className="text-sm text-gray-600 mb-3">{achievement.description}</p>
                <Badge
                  variant={achievement.unlocked ? "default" : "secondary"}
                  className={achievement.unlocked ? "bg-duo-green text-white" : ""}
                  data-testid={`badge-${achievement.id}`}
                >
                  {achievement.unlocked ? "Unlocked" : `${achievement.xpReward} XP`}
                </Badge>
                {achievement.unlocked && achievement.unlockedAt && (
                  <p className="text-xs text-gray-500 mt-2">
                    Unlocked {new Date(achievement.unlockedAt).toLocaleDateString()}
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
}
