// Import generated instructional images
import violinHoldingGuide from './generated_images/Violin_holding_position_guide_3c0bbf8c.png';
import bowGripTechnique from './generated_images/Violin_bow_grip_technique_3485898b.png';

export const instructionalImages = {
  violinHolding: violinHoldingGuide,
  bowGrip: bowGripTechnique,
};

// Map image URLs to imports for dynamic loading
export const getImageUrl = (path: string): string => {
  if (path.includes('Violin_holding_position_guide')) {
    return violinHoldingGuide;
  }
  if (path.includes('Violin_bow_grip_technique')) {
    return bowGripTechnique;
  }
  return path; // fallback to original path
};