import { useQuery } from "@tanstack/react-query";
import { type User } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";

export function DailyGoal() {
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user/demo-user"],
  });

  if (!user) return null;

  const progressPercentage = (user.todayPracticeMinutes / user.dailyGoalMinutes) * 100;
  const remainingMinutes = Math.max(0, user.dailyGoalMinutes - user.todayPracticeMinutes);

  return (
    <Card className="shadow-sm border border-gray-100" data-testid="daily-goal-card">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-duo-gray">Daily Goal</h3>
          <i className="fas fa-target text-duo-orange"></i>
        </div>
        
        <div className="relative mb-4">
          <div className="w-24 h-24 mx-auto">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36" data-testid="progress-circle">
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="#E5E7EB"
                strokeWidth="2"
              />
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="var(--duo-green)"
                strokeWidth="2"
                strokeDasharray={`${progressPercentage}, 100`}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-lg font-bold text-duo-gray" data-testid="goal-progress-text">
                {user.todayPracticeMinutes}/{user.dailyGoalMinutes}
              </span>
            </div>
          </div>
        </div>
        
        <p className="text-center text-sm text-gray-600 mb-3" data-testid="practice-time-today">
          {user.todayPracticeMinutes} minutes practiced today
        </p>
        
        {remainingMinutes > 0 ? (
          <div className="flex items-center justify-center text-duo-green text-sm font-medium" data-testid="remaining-time">
            <i className="fas fa-fire mr-1"></i>
            {remainingMinutes} minutes to go!
          </div>
        ) : (
          <div className="flex items-center justify-center text-duo-green text-sm font-medium" data-testid="goal-completed">
            <i className="fas fa-check-circle mr-1"></i>
            Goal completed! 🎉
          </div>
        )}
      </CardContent>
    </Card>
  );
}
