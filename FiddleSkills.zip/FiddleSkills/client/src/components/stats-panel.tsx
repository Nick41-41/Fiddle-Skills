import { useQuery } from "@tanstack/react-query";
import { type User } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";

export function StatsPanel() {
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user/demo-user"],
  });

  if (!user) return null;

  return (
    <Card className="shadow-sm border border-gray-100" data-testid="stats-panel">
      <CardContent className="p-6">
        <h3 className="text-lg font-bold text-duo-gray mb-4">Your Stats</h3>
        
        <div className="grid grid-cols-2 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-duo-green" data-testid="stat-total-xp">
              {user.totalXp.toLocaleString()}
            </div>
            <div className="text-xs text-gray-600">Total XP</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-duo-orange" data-testid="stat-current-streak">
              {user.currentStreak}
            </div>
            <div className="text-xs text-gray-600">Day Streak</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-duo-blue" data-testid="stat-lessons-completed">
              {user.lessonsCompleted}
            </div>
            <div className="text-xs text-gray-600">Lessons</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-duo-purple" data-testid="stat-practice-time">
              {(user.practiceTimeMinutes / 60).toFixed(1)}h
            </div>
            <div className="text-xs text-gray-600">Practice Time</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
