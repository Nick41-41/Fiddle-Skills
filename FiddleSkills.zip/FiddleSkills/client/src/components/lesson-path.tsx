import { useQuery } from "@tanstack/react-query";
import { type Unit, type Lesson, type UserProgress } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { LessonCard } from "./lesson-card";
import { VirtualViolin } from "./virtual-violin";

export function LessonPath() {

  const { data: units = [] } = useQuery<Unit[]>({
    queryKey: ["/api/units"],
  });

  const { data: progress = [] } = useQuery<UserProgress[]>({
    queryKey: ["/api/user/demo-user/progress"],
  });

  const { data: unit1Lessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/units/unit-1/lessons"],
  });

  const { data: unit2Lessons = [] } = useQuery<Lesson[]>({
    queryKey: ["/api/units/unit-2/lessons"],
  });

  // Calculate overall progress
  const totalLessons = unit1Lessons.length + unit2Lessons.length;
  const completedLessons = progress.filter(p => p.isCompleted).length;
  const progressPercentage = totalLessons > 0 ? (completedLessons / totalLessons) * 100 : 0;



  return (
    <>
      {/* Progress Overview */}
      <Card className="mb-6 shadow-sm border border-gray-100" data-testid="card-progress-overview">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-duo-gray">Your Learning Path</h2>
            <div className="text-sm text-gray-500">Unit 2 of 8</div>
          </div>
          
          {/* Overall Progress Bar */}
          <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
            <Progress value={progressPercentage} className="h-3" data-testid="progress-overall" />
          </div>
          <p className="text-sm text-gray-600" data-testid="text-progress-description">
            You're {Math.round(progressPercentage)}% through the Beginner course!
          </p>
        </CardContent>
      </Card>

      {/* Unit 1: Violin Basics */}
      <Card className="mb-6 shadow-sm border border-gray-100" data-testid="card-unit-1">
        <CardContent className="p-6">
          <h3 className="text-xl font-bold text-duo-gray mb-4 flex items-center">
            <span className="w-8 h-8 bg-duo-green rounded-full flex items-center justify-center text-white text-sm font-bold mr-3">
              1
            </span>
            Violin Basics
          </h3>
          
          <div className="space-y-3">
            {unit1Lessons.map((lesson, index) => {
              const lessonProgress = progress.find(p => p.lessonId === lesson.id);
              const isCompleted = lessonProgress?.isCompleted || false;
              const previousLessonCompleted = index === 0 || progress.find(p => p.lessonId === unit1Lessons[index - 1]?.id)?.isCompleted || false;
              const isCurrentLesson = !isCompleted && previousLessonCompleted;
              const isLocked = !previousLessonCompleted && index > 0;

              return (
                <LessonCard
                  key={lesson.id}
                  lesson={lesson}
                  isCompleted={isCompleted}
                  isCurrent={isCurrentLesson}
                  isLocked={isLocked}
                />
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Unit 2: Basic Bow Techniques */}
      <Card className="mb-6 shadow-sm border border-gray-100" data-testid="card-unit-2">
        <CardContent className="p-6">
          <h3 className="text-xl font-bold text-duo-gray mb-4 flex items-center">
            <span className="w-8 h-8 bg-duo-blue rounded-full flex items-center justify-center text-white text-sm font-bold mr-3">
              2
            </span>
            Basic Bow Techniques
          </h3>
          
          <div className="space-y-3">
            {unit2Lessons.map((lesson, index) => {
              const lessonProgress = progress.find(p => p.lessonId === lesson.id);
              const isCompleted = lessonProgress?.isCompleted || false;
              const previousLessonCompleted = index === 0 || progress.find(p => p.lessonId === unit2Lessons[index - 1]?.id)?.isCompleted || false;
              const isCurrentLesson = !isCompleted && previousLessonCompleted;
              const isLocked = !previousLessonCompleted && index > 0;

              return (
                <LessonCard
                  key={lesson.id}
                  lesson={lesson}
                  isCompleted={isCompleted}
                  isCurrent={isCurrentLesson}
                  isLocked={isLocked}
                />
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Interactive Lesson Preview */}
      <Card className="shadow-sm border border-gray-100" data-testid="card-lesson-preview">
        <CardContent className="p-6">
          <h3 className="text-xl font-bold text-duo-gray mb-4">
            Lesson Preview: Bow Speed Control
          </h3>
          
          <VirtualViolin />
        </CardContent>
      </Card>


    </>
  );
}
