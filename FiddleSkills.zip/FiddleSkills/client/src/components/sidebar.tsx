import { DailyGoal } from "./daily-goal";
import { AchievementsPanel } from "./achievements-panel";
import { QuickPractice } from "./quick-practice";
import { StatsPanel } from "./stats-panel";

export function Sidebar() {
  return (
    <div className="space-y-6">
      <DailyGoal />
      <AchievementsPanel />
      <QuickPractice />
      <StatsPanel />
    </div>
  );
}
