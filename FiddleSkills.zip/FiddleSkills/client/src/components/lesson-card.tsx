import { type Lesson } from "@shared/schema";
import { Link } from "wouter";

interface LessonCardProps {
  lesson: Lesson;
  isCompleted: boolean;
  isCurrent: boolean;
  isLocked: boolean;
  onStart?: () => void;
}

export function LessonCard({ lesson, isCompleted, isCurrent, isLocked, onStart }: LessonCardProps) {
  const getCardStyle = () => {
    if (isCompleted) {
      return "bg-duo-green bg-opacity-10 border-2 border-duo-green";
    }
    if (isCurrent) {
      return "bg-duo-blue bg-opacity-10 border-2 border-duo-blue cursor-pointer hover:shadow-md transition-shadow";
    }
    return "bg-gray-100 border-2 border-gray-200 opacity-60";
  };

  const getIconStyle = () => {
    if (isCompleted) {
      return "w-12 h-12 bg-duo-green rounded-full flex items-center justify-center mr-4";
    }
    if (isCurrent) {
      return "w-12 h-12 bg-duo-blue rounded-full flex items-center justify-center mr-4";
    }
    return "w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center mr-4";
  };

  const getIcon = () => {
    if (isCompleted) return "fas fa-check";
    if (isCurrent) return "fas fa-play";
    return "fas fa-lock";
  };

  const getStatusText = () => {
    if (isCompleted) return "100%";
    if (isCurrent) return "Start";
    return "";
  };

  const getStatusTextColor = () => {
    if (isCompleted) return "text-duo-green";
    if (isCurrent) return "text-duo-blue";
    return "text-gray-500";
  };

  const CardContent = () => (
    <>
      <div className={getIconStyle()}>
        <i className={`${getIcon()} text-white`}></i>
      </div>
      <div className="flex-1">
        <h4 className="font-semibold text-duo-gray" data-testid={`lesson-title-${lesson.id}`}>
          {lesson.name}
        </h4>
        <p className="text-sm text-gray-600" data-testid={`lesson-description-${lesson.id}`}>
          {isCompleted ? "Perfect! +50 XP" : lesson.description}
        </p>
      </div>
      <div className={`font-bold ${getStatusTextColor()}`} data-testid={`lesson-status-${lesson.id}`}>
        {getStatusText()}
      </div>
    </>
  );

  if (isCurrent && !isLocked) {
    return (
      <Link href={`/lesson/${lesson.id}`}>
        <div
          className={`flex items-center p-4 rounded-xl ${getCardStyle()} cursor-pointer hover:shadow-md transition-shadow`}
          data-testid={`lesson-card-${lesson.id}`}
        >
          <CardContent />
        </div>
      </Link>
    );
  }

  return (
    <div
      className={`flex items-center p-4 rounded-xl ${getCardStyle()}`}
      data-testid={`lesson-card-${lesson.id}`}
    >
      <CardContent />
    </div>
  );
}
