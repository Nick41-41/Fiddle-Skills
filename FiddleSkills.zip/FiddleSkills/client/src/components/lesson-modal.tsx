import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { type Lesson } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { apiRequest } from "@/lib/queryClient";

interface LessonModalProps {
  lesson: Lesson;
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
}

export function LessonModal({ lesson, isOpen, onClose, onComplete }: LessonModalProps) {
  const [currentSection, setCurrentSection] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [bowSpeed, setBowSpeed] = useState(50);
  const queryClient = useQueryClient();

  const completeLessonMutation = useMutation({
    mutationFn: async (score: number) => {
      return apiRequest("POST", "/api/progress", {
        userId: "demo-user",
        lessonId: lesson.id,
        score,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/demo-user/progress"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/demo-user"] });
      onComplete();
    },
  });

  if (!isOpen) return null;

  const content = lesson.content as any;
  const sections = content.sections || [];
  const section = sections[currentSection];
  const progressPercentage = ((currentSection + 1) / sections.length) * 100;

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNext = () => {
    if (currentSection < sections.length - 1) {
      setCurrentSection(currentSection + 1);
      setSelectedAnswer(null);
    } else {
      // Complete lesson
      completeLessonMutation.mutate(100);
    }
  };

  const isQuizSection = section?.quiz;
  const canContinue = isQuizSection ? selectedAnswer !== null : true;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" data-testid="lesson-modal">
      <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        {/* Lesson Header */}
        <div className="p-6 border-b border-gray-200 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              onClick={onClose}
              className="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center"
              data-testid="button-close-lesson"
            >
              <i className="fas fa-times text-gray-600"></i>
            </Button>
            <div>
              <h2 className="text-xl font-bold text-duo-gray" data-testid="lesson-modal-title">
                {lesson.name}
              </h2>
              <p className="text-sm text-gray-600">
                Section {currentSection + 1} of {sections.length}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="w-32 bg-gray-200 rounded-full h-2">
              <Progress value={progressPercentage} className="h-2" data-testid="lesson-progress" />
            </div>
            <span className="text-sm text-gray-600">{Math.round(progressPercentage)}%</span>
          </div>
        </div>

        {/* Lesson Content */}
        <div className="p-6">
          {section && (
            <div className="mb-8">
              <h3 className="text-lg font-bold text-duo-gray mb-4" data-testid="section-title">
                {section.title}
              </h3>
              
              <div className="bg-duo-light p-6 rounded-xl">
                <p className="text-gray-700 mb-4" data-testid="section-content">
                  {section.content}
                </p>
                
                {/* Interactive Quiz */}
                {isQuizSection && (
                  <div className="bg-white p-4 rounded-lg border border-gray-200">
                    <h4 className="font-semibold text-duo-gray mb-3" data-testid="quiz-question">
                      {section.quiz.question}
                    </h4>
                    <div className="space-y-2">
                      {section.quiz.options.map((option: string, index: number) => (
                        <button
                          key={index}
                          onClick={() => handleAnswerSelect(index)}
                          className={`w-full p-3 text-left rounded-lg border transition-all ${
                            selectedAnswer === index
                              ? "border-duo-green bg-duo-green bg-opacity-10"
                              : "border-gray-200 hover:border-duo-green hover:bg-duo-green hover:bg-opacity-10"
                          }`}
                          data-testid={`quiz-option-${index}`}
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Practice Exercise */}
                {section.practice && (
                  <div className="bg-amber-50 p-6 rounded-xl border border-amber-200 mt-4">
                    <p className="text-sm text-gray-600 mb-4 text-center">
                      {section.practice.instructions}
                    </p>
                    
                    {/* Bow Speed Slider */}
                    <div className="flex items-center space-x-4 mb-4">
                      <span className="text-sm font-medium">Slow</span>
                      <input
                        type="range"
                        min="1"
                        max="100"
                        value={bowSpeed}
                        onChange={(e) => setBowSpeed(Number(e.target.value))}
                        className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                        data-testid="lesson-bow-speed"
                      />
                      <span className="text-sm font-medium">Fast</span>
                    </div>
                    
                    {/* Play Button */}
                    <div className="text-center">
                      <Button className="w-16 h-16 bg-duo-green hover:bg-green-600 rounded-full text-xl" data-testid="button-practice-play">
                        <i className="fas fa-play"></i>
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              onClick={() => setCurrentSection(Math.max(0, currentSection - 1))}
              disabled={currentSection === 0}
              data-testid="button-previous"
            >
              Previous
            </Button>
            <Button
              onClick={handleNext}
              disabled={!canContinue || completeLessonMutation.isPending}
              className="bg-duo-green hover:bg-green-600"
              data-testid="button-continue"
            >
              {completeLessonMutation.isPending
                ? "Saving..."
                : currentSection === sections.length - 1
                ? "Complete Lesson"
                : "Continue"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
