import { useState } from "react";
import { Button } from "@/components/ui/button";

export function VirtualViolin() {
  const [bowSpeed, setBowSpeed] = useState(50);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);

  const handlePlay = () => {
    setIsPlaying(true);
    setShowFeedback(true);
    
    // Simulate audio playback
    setTimeout(() => {
      setIsPlaying(false);
      setTimeout(() => {
        setShowFeedback(false);
      }, 3000);
    }, 1000);
  };

  return (
    <div className="bg-amber-50 rounded-xl p-6 mb-4 border border-amber-200" data-testid="virtual-violin">
      <h4 className="font-semibold text-duo-gray mb-3 flex items-center">
        <i className="fas fa-guitar text-amber-600 mr-2"></i>
        Virtual Violin Practice
      </h4>
      
      <div className="relative">
        {/* Violin Strings Representation */}
        <div className="space-y-2 mb-4">
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium w-8">E</span>
            <div className="flex-1 h-2 bg-amber-200 rounded-full relative">
              <div 
                className="absolute top-0 left-1/4 w-4 h-4 bg-duo-blue rounded-full -translate-y-1 cursor-pointer shadow-md"
                data-testid="violin-string-e"
              ></div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium w-8">A</span>
            <div className="flex-1 h-2 bg-amber-200 rounded-full" data-testid="violin-string-a"></div>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium w-8">D</span>
            <div className="flex-1 h-2 bg-amber-200 rounded-full" data-testid="violin-string-d"></div>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium w-8">G</span>
            <div className="flex-1 h-2 bg-amber-200 rounded-full" data-testid="violin-string-g"></div>
          </div>
        </div>
        <p className="text-sm text-gray-600 mb-4">
          Place your finger on the blue dot and practice slow bow movements
        </p>
      </div>

      {/* Bow Speed Control */}
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">Bow Speed</label>
        <div className="flex items-center space-x-4">
          <span className="text-sm">Slow</span>
          <input
            type="range"
            min="1"
            max="100"
            value={bowSpeed}
            onChange={(e) => setBowSpeed(Number(e.target.value))}
            className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            data-testid="bow-speed-slider"
          />
          <span className="text-sm">Fast</span>
        </div>
        <p className="text-xs text-gray-500 mt-1" data-testid="bow-speed-value">
          Speed: {bowSpeed}%
        </p>
      </div>

      {/* Audio Controls */}
      <div className="flex items-center justify-center space-x-4 p-4 bg-gray-50 rounded-xl">
        <Button
          onClick={handlePlay}
          disabled={isPlaying}
          className="w-12 h-12 bg-duo-green hover:bg-green-600 rounded-full flex items-center justify-center text-white"
          data-testid="button-play-violin"
        >
          <i className={`fas ${isPlaying ? 'fa-spinner fa-spin' : 'fa-play'}`}></i>
        </Button>
        
        <div className="flex-1 max-w-xs">
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-duo-green h-2 rounded-full transition-all duration-300"
              style={{ width: isPlaying ? '100%' : '0%' }}
              data-testid="audio-progress"
            ></div>
          </div>
        </div>
        <span className="text-sm text-gray-600">0:00 / 0:15</span>
      </div>

      {/* Feedback Area */}
      {showFeedback && (
        <div className="text-center mt-4" data-testid="feedback-area">
          <div className="inline-flex items-center space-x-2 bg-duo-green bg-opacity-10 text-duo-green px-4 py-2 rounded-lg">
            <i className="fas fa-check-circle"></i>
            <span>Great! Perfect bow speed control!</span>
          </div>
        </div>
      )}
    </div>
  );
}
