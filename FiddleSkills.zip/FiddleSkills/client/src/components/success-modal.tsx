import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface SuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  xpEarned: number;
  streak: number;
}

export function SuccessModal({ isOpen, onClose, xpEarned, streak }: SuccessModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" data-testid="success-modal">
      <div className="bg-white rounded-2xl p-8 max-w-md w-full text-center">
        <div className="w-20 h-20 bg-duo-yellow rounded-full flex items-center justify-center mx-auto mb-4">
          <i className="fas fa-trophy text-white text-2xl"></i>
        </div>
        
        <h2 className="text-2xl font-bold text-duo-gray mb-2" data-testid="success-title">
          Lesson Complete!
        </h2>
        <p className="text-gray-600 mb-6" data-testid="success-description">
          You've mastered bow speed control and earned {xpEarned} XP!
        </p>
        
        <div className="space-y-3 mb-6">
          <div className="flex items-center justify-between p-3 bg-duo-green bg-opacity-10 rounded-lg">
            <span className="text-duo-gray font-medium">XP Earned</span>
            <Badge className="bg-duo-green text-white" data-testid="badge-xp-earned">
              +{xpEarned}
            </Badge>
          </div>
          <div className="flex items-center justify-between p-3 bg-duo-orange bg-opacity-10 rounded-lg">
            <span className="text-duo-gray font-medium">Streak</span>
            <Badge className="bg-duo-orange text-white" data-testid="badge-streak">
              {streak} days 🔥
            </Badge>
          </div>
        </div>
        
        <Button 
          onClick={onClose}
          className="w-full bg-duo-green hover:bg-green-600"
          data-testid="button-continue-learning"
        >
          Continue Learning
        </Button>
      </div>
    </div>
  );
}
