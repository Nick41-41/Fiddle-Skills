import { Link } from "wouter";

interface MainNavigationProps {
  activeTab: string;
}

export function MainNavigation({ activeTab }: MainNavigationProps) {
  const tabs = [
    { id: "learn", label: "Learn", icon: "fas fa-home", path: "/" },
    { id: "practice", label: "Practice", icon: "fas fa-dumbbell", path: "/practice" },
    { id: "achievements", label: "Achievements", icon: "fas fa-trophy", path: "/achievements" },
    { id: "progress", label: "Progress", icon: "fas fa-chart-line", path: "/progress" },
  ];

  return (
    <nav className="bg-white border-b border-gray-200">
      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="flex space-x-8 overflow-x-auto">
          {tabs.map((tab) => (
            <Link key={tab.id} href={tab.path}>
              <button
                className={`flex items-center space-x-2 pb-2 font-semibold whitespace-nowrap ${
                  activeTab === tab.id
                    ? "text-duo-green border-b-2 border-duo-green"
                    : "text-gray-500 hover:text-duo-gray font-medium"
                }`}
                data-testid={`tab-${tab.id}`}
              >
                <i className={tab.icon}></i>
                <span>{tab.label}</span>
              </button>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}
