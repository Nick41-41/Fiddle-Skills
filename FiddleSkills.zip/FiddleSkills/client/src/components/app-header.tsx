import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { type User } from "@shared/schema";
import { useAuth } from "@/hooks/useAuth";

export function AppHeader() {
  const { user: authUser, isAuthenticated } = useAuth();
  
  // Fallback to demo user for development if not authenticated
  const { data: demoUser } = useQuery<User>({
    queryKey: ["/api/user/demo-user"],
    enabled: !isAuthenticated,
  });
  
  // Use authenticated user data if available, otherwise demo user
  const user = isAuthenticated ? (authUser as User) : demoUser;

  return (
    <header className="bg-white shadow-sm border-b-2 border-duo-green">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-duo-green rounded-full flex items-center justify-center">
            <i className="fas fa-music text-white text-lg"></i>
          </div>
          <h1 className="text-xl font-bold text-duo-gray" data-testid="text-app-title">ViolinMaster</h1>
        </div>
        
        <div className="flex items-center space-x-6">
          {/* Streak Counter */}
          <div className="flex items-center space-x-2 bg-duo-orange bg-opacity-10 px-3 py-2 rounded-lg">
            <i className="fas fa-fire text-duo-orange"></i>
            <span className="font-bold text-white" data-testid="text-streak">
              {user?.currentStreak || 0}
            </span>
          </div>
          
          {/* XP Display */}
          <div className="flex items-center space-x-2 bg-duo-blue bg-opacity-10 px-3 py-2 rounded-lg">
            <i className="fas fa-star text-duo-blue"></i>
            <span className="font-bold text-white" data-testid="text-xp">
              {user?.totalXp?.toLocaleString() || 0} XP
            </span>
          </div>
          
          {/* User Profile and Actions */}
          <div className="flex items-center space-x-3">
            {isAuthenticated ? (
              <>
                <div className="w-8 h-8 bg-duo-purple rounded-full flex items-center justify-center">
                  <i className="fas fa-user text-white"></i>
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => window.location.href = "/api/logout"}
                  data-testid="button-logout"
                >
                  <i className="fas fa-sign-out-alt mr-2"></i>
                  Logout
                </Button>
              </>
            ) : (
              <Button 
                onClick={() => window.location.href = "/api/login"}
                data-testid="button-login-header"
              >
                <i className="fas fa-sign-in-alt mr-2"></i>
                Login
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
