import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface AchievementWithStatus {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  unlocked: boolean;
}

export function AchievementsPanel() {
  const { data: achievements = [] } = useQuery<AchievementWithStatus[]>({
    queryKey: ["/api/user/demo-user/achievements"],
  });

  const recentAchievements = achievements.filter(a => a.unlocked).slice(0, 3);

  return (
    <Card className="shadow-sm border border-gray-100" data-testid="achievements-panel">
      <CardContent className="p-6">
        <h3 className="text-lg font-bold text-duo-gray mb-4 flex items-center">
          <i className="fas fa-trophy text-duo-yellow mr-2"></i>
          Achievements
        </h3>
        
        <div className="space-y-3">
          {recentAchievements.map((achievement) => (
            <div
              key={achievement.id}
              className={`flex items-center p-3 rounded-lg border ${
                achievement.color === "yellow"
                  ? "bg-duo-yellow bg-opacity-10 border-duo-yellow"
                  : achievement.color === "green"
                  ? "bg-duo-green bg-opacity-10 border-duo-green"
                  : "bg-duo-blue bg-opacity-10 border-duo-blue"
              }`}
              data-testid={`achievement-item-${achievement.id}`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 ${
                  achievement.color === "yellow"
                    ? "bg-duo-yellow"
                    : achievement.color === "green"
                    ? "bg-duo-green"
                    : "bg-duo-blue"
                }`}
              >
                <i className={`${achievement.icon} text-white text-sm`}></i>
              </div>
              <div>
                <p className="font-semibold text-sm text-duo-gray" data-testid={`achievement-name-${achievement.id}`}>
                  {achievement.name}
                </p>
                <p className="text-xs text-gray-600" data-testid={`achievement-description-${achievement.id}`}>
                  {achievement.description}
                </p>
              </div>
            </div>
          ))}
        </div>
        
        <Link href="/achievements">
          <Button
            variant="ghost"
            className="w-full mt-4 text-duo-blue hover:bg-duo-blue hover:bg-opacity-10"
            data-testid="button-view-all-achievements"
          >
            View All Achievements
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
