import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

export function QuickPractice() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user, isAuthenticated } = useAuth();

  const practiceSessionMutation = useMutation({
    mutationFn: async (minutes: number) => {
      const userId = (user as any)?.id || "demo-user";
      return apiRequest("POST", "/api/practice", {
        userId,
        minutes,
      });
    },
    onSuccess: () => {
      // Invalidate the correct user query based on authentication status
      if (isAuthenticated) {
        queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      } else {
        queryClient.invalidateQueries({ queryKey: ["/api/user", "demo-user"] });
      }
      
      toast({
        title: "Practice Session Complete!",
        description: "Great job on your practice session!",
      });
    },
  });

  const handleQuickPractice = (minutes: number) => {
    practiceSessionMutation.mutate(minutes);
  };

  return (
    <Card className="shadow-sm border border-gray-100" data-testid="quick-practice-card">
      <CardContent className="p-6">
        <h3 className="text-lg font-bold text-duo-gray mb-4 flex items-center">
          <i className="fas fa-dumbbell text-duo-purple mr-2"></i>
          Quick Practice
        </h3>
        
        <div className="space-y-3">
          <Button
            onClick={() => handleQuickPractice(5)}
            disabled={practiceSessionMutation.isPending}
            className="w-full bg-duo-green hover:bg-green-600 text-white flex items-center justify-center"
            data-testid="button-practice-scales"
          >
            <i className="fas fa-play mr-2"></i>
            Practice Scales (5 min)
          </Button>
          
          <Button
            onClick={() => handleQuickPractice(3)}
            disabled={practiceSessionMutation.isPending}
            className="w-full bg-duo-blue hover:bg-blue-600 text-white flex items-center justify-center"
            data-testid="button-note-recognition"
          >
            <i className="fas fa-music mr-2"></i>
            Note Recognition (3 min)
          </Button>
          
          <Button
            onClick={() => handleQuickPractice(4)}
            disabled={practiceSessionMutation.isPending}
            className="w-full bg-duo-purple hover:bg-purple-600 text-white flex items-center justify-center"
            data-testid="button-ear-training"
          >
            <i className="fas fa-ear-listen mr-2"></i>
            Ear Training (4 min)
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
