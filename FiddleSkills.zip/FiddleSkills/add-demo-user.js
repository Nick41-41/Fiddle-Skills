import { Pool } from '@neondatabase/serverless';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function addDemoUser() {
  try {
    await pool.query(`
      INSERT INTO users (id, email, username, first_name, last_name, total_xp, current_streak, longest_streak, lessons_completed, practice_time_minutes, current_level, daily_goal_minutes, today_practice_minutes, last_practice_date, created_at, updated_at)
      VALUES ('demo-user', 'demo@violinmaster.com', 'demo-user', 'Demo', 'User', 150, 3, 5, 2, 45, 2, 20, 15, $1, NOW(), NOW())
      ON CONFLICT (id) DO NOTHING;
    `, [new Date().toISOString().split('T')[0]]);
    
    console.log('Demo user added successfully!');
  } catch (error) {
    console.error('Error adding demo user:', error);
  } finally {
    await pool.end();
  }
}

addDemoUser();