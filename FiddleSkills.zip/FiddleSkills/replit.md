# ViolinMaster Learning App

## Overview

ViolinMaster is a web-based violin learning application built as a Duolingo-style interactive platform. The app provides structured violin lessons, practice tracking, achievements, and progress monitoring to help users learn violin in an engaging, gamified environment. The application features a comprehensive lesson system with interactive content, virtual violin practice tools, and social elements like streaks and achievements to maintain user engagement.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript for type safety and modern development practices
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Components**: Radix UI with shadcn/ui for accessible, customizable components
- **Styling**: Tailwind CSS with custom Duolingo-inspired color scheme and design tokens
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API endpoints
- **Language**: TypeScript throughout for consistency and type safety
- **Development Mode**: TSX for running TypeScript directly in development
- **Production Build**: ESBuild for bundling the server application

### Data Storage Solutions
- **Database**: PostgreSQL as the primary database using Neon serverless
- **ORM**: Drizzle ORM for type-safe database operations and schema management
- **Connection**: @neondatabase/serverless for optimized serverless database connections
- **Schema**: Comprehensive schema with tables for users, units, lessons, progress tracking, achievements, and user achievements

### Core Features Architecture
- **Lesson System**: Structured units containing sequential lessons with interactive content (JSON-based lesson content, audio integration, progress tracking)
- **Gamification**: XP system, daily streaks, achievement unlocking, and level progression
- **Practice Tools**: Virtual violin interface with string visualization and interactive practice sessions
- **Progress Tracking**: Individual lesson completion, daily practice time tracking, and comprehensive user statistics

### API Design
- **RESTful Endpoints**: Standard HTTP methods for user management, lesson retrieval, and progress updates
- **Resource Structure**: 
  - `/api/user/:id` for user data and updates
  - `/api/units` and `/api/units/:id/lessons` for lesson content
  - `/api/lessons/:id` for individual lesson details
  - Progress tracking and achievement endpoints
- **Error Handling**: Centralized error handling with proper HTTP status codes

### Authentication Strategy
- Currently uses demo user system for development
- Architecture supports session-based authentication with connect-pg-simple for session storage
- Designed to easily integrate proper user authentication when needed

### Development Workflow
- **Hot Module Replacement**: Vite middleware integration for instant development feedback
- **Database Migrations**: Drizzle Kit for schema management and database migrations
- **Type Safety**: Shared schema definitions between client and server
- **Code Quality**: TypeScript strict mode with comprehensive type checking

### Deployment Considerations
- **Build Process**: Separate client (Vite) and server (ESBuild) build steps
- **Static Assets**: Client builds to `dist/public` for easy static file serving
- **Environment Variables**: Database connection via `DATABASE_URL` environment variable
- **Production Server**: Express serves both API endpoints and static client files

## External Dependencies

### Database Infrastructure
- **Neon Database**: Serverless PostgreSQL hosting with `@neondatabase/serverless` driver
- **Drizzle ORM**: Type-safe database operations with `drizzle-orm` and `drizzle-zod` for validation
- **Session Store**: `connect-pg-simple` for PostgreSQL-backed session management

### UI and Styling Libraries
- **Component Library**: Radix UI primitives for accessible, unstyled components
- **Design System**: shadcn/ui component library built on Radix UI
- **Styling**: Tailwind CSS for utility-first styling approach
- **Icons**: Font Awesome classes used throughout the interface
- **Fonts**: Google Fonts integration (Inter, Architects Daughter, DM Sans, Fira Code, Geist Mono)

### State Management and Data Fetching
- **TanStack Query**: Server state management, caching, and synchronization
- **Form Management**: React Hook Form with Hookform Resolvers for form validation
- **Validation**: Zod schema validation integrated with Drizzle

### Development and Build Tools
- **Build Tool**: Vite with React plugin for fast development and optimized builds
- **TypeScript**: Full TypeScript support with strict type checking
- **Development Server**: Custom Vite middleware integration for seamless full-stack development
- **Runtime**: TSX for direct TypeScript execution in development

### Utility Libraries
- **Date Handling**: date-fns for date manipulation and formatting
- **Class Management**: clsx and class-variance-authority for conditional CSS classes
- **Carousel**: Embla Carousel React for interactive lesson content
- **Command Interface**: cmdk for command palette functionality
- **Unique IDs**: nanoid for generating unique identifiers

### Replit Integration
- **Error Overlay**: @replit/vite-plugin-runtime-error-modal for development error handling
- **Development Tools**: @replit/vite-plugin-cartographer for enhanced Replit development experience
- **Environment Detection**: Replit-specific environment variable handling